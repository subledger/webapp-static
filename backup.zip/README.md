## Require NodeJS and NPM installed (Tested on PC)
##To start (in command line):

### > npm install
### > npm install -g node-static
### > npm install -g grunt-cli
### > npm install -g bower

### > bower install
### > grunt build (or 'grunt dev' for developpement)
### > cd dist (or 'cd src' for developpement)
###   > static

Then open browser at http://localhost:8080/


##Time Picker
http://jonthornton.github.io/jquery-timepicker/


## Date picker
http://jqueryui.com/datepicker/

##Fonts
PT Sans
http://www.google.com/fonts/specimen/PT+Sans