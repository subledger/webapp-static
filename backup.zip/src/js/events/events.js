
define([
    'backbone'
], function (Backbone ) {
    var AppEvents = Backbone.Events;

    return AppEvents;
});