define([
    'backbone',
    'supermodel'
], function (Backbone, Supermodel) {
    'use strict';

    var Journal_entryline = Supermodel.Model.extend({
        url : 'whaterver',
        default:{

        }

    });


    return Journal_entryline;
});

