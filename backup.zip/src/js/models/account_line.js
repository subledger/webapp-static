define([
    'backbone',
    'supermodel'
], function (Backbone, Supermodel) {
    'use strict';

    var Account_line = Supermodel.Model.extend({
        url : 'whaterver',
        default:{

        }

    });


    return Account_line;
});

