Please see [pathable.github.com/supermodel][supermodel] for documentation.

[supermodel]: [http://pathable.github.com/supermodel]
