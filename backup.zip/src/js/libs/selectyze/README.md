# Readme

Full documentation on [MyJqueryPlugins](http://www.myjqueryplugins.com/Selectyze)

Demonstration on [Selectyze demonstration page](http://www.myjqueryplugins.com/Selectyze/demo)