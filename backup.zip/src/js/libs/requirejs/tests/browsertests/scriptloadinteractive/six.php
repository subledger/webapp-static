<?php
sleep(2)
?>

def(function () {
    return {
        name: 'six'
    };
});
